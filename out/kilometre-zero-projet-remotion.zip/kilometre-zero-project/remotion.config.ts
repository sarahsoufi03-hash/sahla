import {existsSync} from 'node:fs';
import {Config} from '@remotion/cli/config';

// Prefer the installed browser on this cloud machine. On another OS Remotion
// can use its managed browser, or REMOTION_BROWSER_EXECUTABLE can override it.
const browser = process.env.REMOTION_BROWSER_EXECUTABLE;
if (browser) Config.setBrowserExecutable(browser);
else if (existsSync('/usr/bin/chromium')) Config.setBrowserExecutable('/usr/bin/chromium');
