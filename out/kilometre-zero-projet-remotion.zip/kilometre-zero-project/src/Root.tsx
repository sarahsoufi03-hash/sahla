import React from 'react';
import {Composition} from 'remotion';
import {KilometreZero} from './KilometreZero';

export const Root = () => (
  <Composition
    id="KilometreZero"
    component={KilometreZero}
    durationInFrames={1800}
    fps={60}
    width={1080}
    height={1920}
  />
);
