import React, {useEffect, useState} from 'react';
import {
  AbsoluteFill, Img, Sequence, staticFile, useCurrentFrame, interpolate,
  delayRender, continueRender, cancelRender,
} from 'remotion';
import {Video, Audio} from '@remotion/media';
import './style.css';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const orange = '#ff6428';

const Fonts = () => {
  const [handle] = useState(() => delayRender('Load local DejaVu fonts'));
  useEffect(() => {
    Promise.all([
      new FontFace('SahlaBold', `url(${staticFile('fonts/DejaVuSansCondensed-Bold.ttf')})`).load(),
      new FontFace('SahlaRegular', `url(${staticFile('fonts/DejaVuSans.ttf')})`).load(),
    ]).then((faces) => {
      for (const face of faces) document.fonts.add(face);
      continueRender(handle);
    }).catch(cancelRender);
  }, [handle]);
  return null;
};

// Original footage only: source trims / restrained reframing, never regenerated.
const Footage = ({trim, speed = 1, zoomTo = 1, frames}: {
  trim: number; speed?: number; zoomTo?: number; frames: number;
}) => {
  const frame = useCurrentFrame();
  return <AbsoluteFill style={{overflow: 'hidden', background: '#080d13'}}>
    <Video
      src={staticFile('source.mp4')}
      trimBefore={Math.round(trim * 60)}
      playbackRate={speed}
      muted
      objectFit="cover"
      style={{
        width: '100%', height: '100%',
        scale: interpolate(frame, [0, frames - 1], [1, zoomTo], clamp),
      }}
    />
  </AbsoluteFill>;
};

const Hook = () => {
  const frame = useCurrentFrame();
  return <AbsoluteFill>
    <div style={{position: 'absolute', left: 0, top: 90, width: 1080, height: 570,
      background: 'linear-gradient(180deg, transparent, rgba(3,8,12,.78) 23%, rgba(3,8,12,.72) 68%, transparent)'}} />
    <div data-safe="hook" style={{position: 'absolute', left: 92, top: 223, width: 820,
      fontFamily: 'SahlaBold', fontSize: 94, lineHeight: 1.06, letterSpacing: -2,
      color: 'white', translate: `0 ${interpolate(frame, [0, 9], [9, 0], clamp)}px`,
      textShadow: '0 4px 18px #0008'}}>
      OUI, C’EST<br />UN <span style={{color: orange}}>SITE WEB</span>.
    </div>
  </AbsoluteFill>;
};

const ScrollHint = () => {
  const frame = useCurrentFrame();
  return <AbsoluteFill>
    <div style={{position: 'absolute', top: 215, left: 36, width: 960, height: 340,
      background: 'radial-gradient(ellipse, rgba(4,8,12,.78), rgba(4,8,12,.40) 60%, transparent 75%)'}} />
    <div data-safe="scroll" style={{position: 'absolute', left: 100, top: 303, width: 800,
      fontFamily: 'SahlaBold', fontSize: 56, lineHeight: 1.16, color: 'white',
      opacity: interpolate(frame, [0, 5, 226, 239], [0, 1, 1, 0], clamp),
      translate: `0 ${interpolate(frame, [0, 10], [10, 0], clamp)}px`,
      textShadow: '0 3px 14px #000b'}}>
      Regarde ce qui se<br />passe au scroll.
    </div>
  </AbsoluteFill>;
};

const OutroTransition = () => {
  const frame = useCurrentFrame();
  return <AbsoluteFill style={{backgroundColor: '#080d13',
    opacity: interpolate(frame, [68, 125], [0, .70], clamp)}} />;
};

const FollowCard = () => {
  const frame = useCurrentFrame();
  return <AbsoluteFill style={{background: '#080d13', color: '#fff',
    opacity: interpolate(frame, [0, 12], [.15, 1], clamp)}}>
    <div style={{position: 'absolute', left: 100, top: 282, width: 64, height: 6, background: orange}} />
    <div data-safe="end-headline" style={{position: 'absolute', left: 100, top: 330, width: 810,
      fontFamily: 'SahlaBold', fontSize: 92, lineHeight: 1.03, letterSpacing: -2,
      translate: `0 ${interpolate(frame, [0, 15], [12, 0], clamp)}px`}}>
      LE RUNNING.<br /><span style={{color: orange}}>EN IMMERSION.</span>
    </div>
    <Img src={staticFile('end-devices.png')} style={{position: 'absolute', left: 80,
      top: 600, width: 870, height: 700, objectFit: 'contain',
      scale: interpolate(frame, [0, 281], [1, 1.025], clamp)}} />
    <div data-safe="end-cta" style={{position: 'absolute', left: 100, top: 1325, width: 810,
      fontFamily: 'SahlaRegular', fontSize: 43, lineHeight: 1.25}}>
      Pour d’autres sites comme ça,
    </div>
    <div data-safe="end-handle" style={{position: 'absolute', left: 100, top: 1390, width: 810,
      fontFamily: 'SahlaBold', fontSize: 81, letterSpacing: -1, color: orange}}>
      suis @sahladzai
    </div>
    <div data-safe="end-demo" style={{position: 'absolute', left: 100, top: 1560, width: 810,
      fontFamily: 'SahlaRegular', fontSize: 26, color: '#9da4ae'}}>
      Projet fictif — démo SAHLA
    </div>
  </AbsoluteFill>;
};

export const KilometreZero = () => <AbsoluteFill style={{background: '#080d13'}}>
  <Fonts />
  {/* Each shot is independently editable. Times are 60 fps output frames. */}
  <Sequence name="01 · Hook / chaussure éclatée" from={0} durationInFrames={48}>
    <Footage trim={4.05} frames={48} />
  </Sequence>
  <Sequence name="02 · Pièces / semelle" from={48} durationInFrames={51}>
    <Footage trim={5.55} speed={1.2941176471} frames={51} />
  </Sequence>
  <Sequence name="03 · Tige / lacets" from={99} durationInFrames={69}>
    <Footage trim={6.85} speed={1.3043478261} frames={69} />
  </Sequence>
  <Sequence name="04 · Chaussure finale / étincelles" from={168} durationInFrames={120}>
    <Footage trim={8.35} speed={1.1} frames={120} />
  </Sequence>
  <Sequence name="05 · Révélation du site" from={288} durationInFrames={102}>
    <Footage trim={11.45} speed={1.1764705882} frames={102} />
  </Sequence>
  <Sequence name="06 · Page produit ordinateur" from={390} durationInFrames={240}>
    <Footage trim={13.7} speed={1.025} zoomTo={1.035} frames={240} />
  </Sequence>
  <Sequence name="07 · Site responsive / mobile" from={630} durationInFrames={210}>
    <Footage trim={18.1} speed={.8} zoomTo={1.04} frames={210} />
  </Sequence>
  <Sequence name="08 · Page éclatée 3D" from={840} durationInFrames={300}>
    <Footage trim={20.9} speed={.66} frames={300} />
  </Sequence>
  <Sequence name="09 · Runners / Alger" from={1140} durationInFrames={252}>
    <Footage trim={25.5} speed={.5119047619} frames={252} />
  </Sequence>
  <Sequence name="10 · Retour sportif / transition carte" from={1392} durationInFrames={126}>
    <Footage trim={28.5} speed={.69} frames={126} />
    <OutroTransition />
  </Sequence>
  <Sequence name="Hook texte" from={0} durationInFrames={48}><Hook /></Sequence>
  <Sequence name="Invitation au scroll" from={48} durationInFrames={240}><ScrollHint /></Sequence>
  <Sequence name="11 · Abonnement / @sahladzai" from={1518} durationInFrames={282}>
    <FollowCard />
  </Sequence>
  {/* Exactly seven synthetic accents. Source audio deliberately muted. */}
  <Sequence name="SFX 01 · Hook" from={0} durationInFrames={24} layout="none">
    <Audio src={staticFile('sfx/01-hook.wav')} />
  </Sequence>
  <Sequence name="SFX 02 · Mouvement" from={48} durationInFrames={36} layout="none">
    <Audio src={staticFile('sfx/02-scroll-air.wav')} />
  </Sequence>
  <Sequence name="SFX 03 · Assemblage" from={99} durationInFrames={12} layout="none">
    <Audio src={staticFile('sfx/03-assembly.wav')} />
  </Sequence>
  <Sequence name="SFX 04 · Lacets" from={168} durationInFrames={12} layout="none">
    <Audio src={staticFile('sfx/04-laces.wav')} />
  </Sequence>
  <Sequence name="SFX 05 · Verrouillage" from={225} durationInFrames={12} layout="none">
    <Audio src={staticFile('sfx/05-lock.wav')} />
  </Sequence>
  <Sequence name="SFX 06 · Ordinateur vers mobile" from={630} durationInFrames={36} layout="none">
    <Audio src={staticFile('sfx/06-mobile-air.wav')} />
  </Sequence>
  <Sequence name="SFX 07 · Abonnement" from={1518} durationInFrames={30} layout="none">
    <Audio src={staticFile('sfx/07-follow.wav')} />
  </Sequence>
</AbsoluteFill>;
