import {bundle} from '@remotion/bundler';
import {openBrowser, renderStill, selectComposition} from '@remotion/renderer';
import path from 'node:path';
import {mkdirSync, existsSync} from 'node:fs';

mkdirSync('analysis', {recursive: true});
const serveUrl = await bundle({entryPoint: path.resolve('src/index.ts')});
const browser = await openBrowser('chrome', {browserExecutable: process.env.REMOTION_BROWSER_EXECUTABLE || (existsSync('/usr/bin/chromium') ? '/usr/bin/chromium' : undefined)});
try {
  const composition = await selectComposition({serveUrl, id: 'KilometreZero', puppeteerInstance: browser});
  for (const frame of [0, 80, 225, 288, 335, 550, 670, 980, 1210, 1450, 1580, 1799]) {
    await renderStill({serveUrl, composition, frame, puppeteerInstance: browser,
      output: `analysis/check-${frame}.png`, imageFormat: 'png'});
    console.log(`Checked frame ${frame} (${(frame / 60).toFixed(3)} s)`);
  }
} finally {
  await browser.close({silent: true});
}
