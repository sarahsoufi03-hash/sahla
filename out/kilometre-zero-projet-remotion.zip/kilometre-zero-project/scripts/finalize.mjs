import {spawnSync} from 'node:child_process';
import {renameSync} from 'node:fs';

// Standard limited-range Rec.709 delivery. No scene changes; preserve 60 fps.
const result = spawnSync('ffmpeg', [
  '-hide_banner', '-loglevel', 'error', '-y',
  '-i', 'out/kilometre-zero-remotion.mp4', '-t', '30',
  '-vf', 'scale=in_range=pc:out_range=tv,format=yuv420p',
  '-c:v', 'libx264', '-preset', 'fast', '-crf', '17', '-threads', '4',
  '-color_range', 'tv', '-colorspace', 'bt709',
  '-color_primaries', 'bt709', '-color_trc', 'bt709',
  '-c:a', 'copy', '-movflags', '+faststart',
  'out/kilometre-zero-final-tmp.mp4',
], {stdio: 'inherit'});
if (result.error) throw result.error;
if (result.status !== 0) process.exit(result.status ?? 1);
renameSync('out/kilometre-zero-final-tmp.mp4', 'out/kilometre-zero-final.mp4');
console.log('Final MP4: H.264, 1080×1920, 60 fps, Rec.709 yuv420p, AAC.');
