"""Deterministic, original synthetic foley. No recordings, music or API calls.

Requires numpy and scipy. The generated effects may be used commercially (CC0).
"""
from pathlib import Path
import json
import wave
import numpy as np
from scipy.signal import butter, sosfilt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'public' / 'sfx'
OUT.mkdir(parents=True, exist_ok=True)
(ROOT / 'analysis').mkdir(exist_ok=True)
SR = 48000
RNG = np.random.default_rng(703)


def noise(n, lo, hi):
    return sosfilt(butter(2, [lo, hi], btype='bandpass', fs=SR, output='sos'), RNG.normal(0, 1, n))


def save(name, x, peak):
    # Small anti-click ramps on both ends; stereo with no exaggerated panning.
    ramp = min(240, len(x) // 8)
    x[:ramp] *= np.linspace(0, 1, ramp)
    x[-ramp:] *= np.linspace(1, 0, ramp)
    x = x / max(np.max(np.abs(x)), 1e-10) * peak
    stereo = np.stack([x, x * .97], axis=1)
    with wave.open(str(OUT / name), 'wb') as f:
        f.setnchannels(2)
        f.setsampwidth(2)
        f.setframerate(SR)
        f.writeframes(np.int16(np.clip(stereo, -1, 1) * 32767).tobytes())


t = np.arange(int(.34 * SR)) / SR
impact = np.sin(2 * np.pi * (86 * t - 42 * t * t)) * np.exp(-t * 23)
impact += .22 * noise(len(t), 180, 1500) * np.exp(-t * 45)
save('01-hook.wav', impact, .22)

t = np.arange(int(.58 * SR)) / SR
save('02-scroll-air.wav', noise(len(t), 260, 2400) * np.sin(np.pi * t / .58) ** 2, .13)

for name, freq, peak in [('03-assembly.wav', 610, .145), ('04-laces.wav', 850, .12), ('05-lock.wav', 490, .17)]:
    t = np.arange(int(.17 * SR)) / SR
    x = .7 * noise(len(t), 330, 2200) * np.exp(-t * 72)
    x += .3 * np.sin(2 * np.pi * freq * t) * np.exp(-t * 95)
    save(name, x, peak)

t = np.arange(int(.52 * SR)) / SR
save('06-mobile-air.wav', noise(len(t), 350, 2100) * np.sin(np.pi * t / .52) ** 2, .10)

t = np.arange(int(.42 * SR)) / SR
x = np.sin(2 * np.pi * (112 * t - 31 * t * t)) * np.exp(-t * 21)
x += .13 * noise(len(t), 260, 1500) * np.exp(-t * 35)
save('07-follow.wav', x, .20)

(OUT / 'LICENSE.txt').write_text('Original synthetic sound effects generated for SAHLA.\nCC0 1.0: dedicated to the public domain; commercial use permitted.\nNo third-party recording, music, voice or paid service used.\n')
events = [
    {'at': 0, 'file': '01-hook.wav', 'purpose': 'Impact doux du hook'},
    {'at': .8, 'file': '02-scroll-air.wav', 'purpose': 'Souffle du mouvement principal'},
    {'at': 1.65, 'file': '03-assembly.wav', 'purpose': 'Assemblage / pièces'},
    {'at': 2.8, 'file': '04-laces.wav', 'purpose': 'Assemblage / lacets'},
    {'at': 3.75, 'file': '05-lock.wav', 'purpose': 'Verrouillage final / étincelles'},
    {'at': 10.5, 'file': '06-mobile-air.wav', 'purpose': 'Passage ordinateur vers mobile'},
    {'at': 25.3, 'file': '07-follow.wav', 'purpose': 'Apparition de la carte abonnement'},
]
(ROOT / 'analysis' / 'sfx-events.json').write_text(json.dumps(events, ensure_ascii=False, indent=2))
print('Generated seven short original effects at 48 kHz stereo, maximum peak -13.15 dBFS.')
