"""Verify the delivered MP4 (requires FFmpeg, ffprobe, numpy)."""
from pathlib import Path
import hashlib
import json
import subprocess
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
P = ROOT / 'out/kilometre-zero-final.mp4'
meta = json.loads(subprocess.check_output([
    'ffprobe', '-v', 'error', '-show_format', '-show_streams', '-of', 'json', str(P)
]))
v = next(s for s in meta['streams'] if s['codec_type'] == 'video')
a = next(s for s in meta['streams'] if s['codec_type'] == 'audio')
assert (v['width'], v['height'], v['avg_frame_rate'], v['nb_frames'], v['codec_name'], v['pix_fmt']) == (
    1080, 1920, '60/1', '1800', 'h264', 'yuv420p'
), v
assert a['codec_name'] == 'aac' and a['sample_rate'] == '48000', a
assert abs(float(meta['format']['duration']) - 30) < .05
subprocess.run(['ffmpeg', '-v', 'error', '-i', str(P), '-f', 'null', '-'], check=True)
raw = subprocess.check_output([
    'ffmpeg', '-v', 'error', '-i', str(P), '-vn', '-acodec', 'pcm_f32le',
    '-ar', '48000', '-ac', '2', '-f', 'f32le', '-'
])
s = np.frombuffer(raw, dtype='<f4').reshape(-1, 2)
peak = float(np.max(np.abs(s)))
windows = s[:len(s) // 480 * 480].reshape(-1, 480, 2)
rms = np.sqrt(np.mean(windows ** 2, axis=(1, 2)))
groups = []
for k in np.flatnonzero(rms > 10 ** (-60 / 20)):
    if not groups or k - groups[-1][-1] > 5:
        groups.append([int(k)])
    else:
        groups[-1].append(int(k))
regions = [{'start': g[0] / 100, 'end': (g[-1] + 1) / 100} for g in groups]
expected = [0, .8, 1.65, 2.8, 3.75, 10.5, 25.3]
assert len(regions) == 7, regions
for region, onset in zip(regions, expected):
    assert abs(region['start'] - onset) < .06, (region, onset)
assert peak < .32, peak
report = {
    'file': P.name,
    'sha256': hashlib.sha256(P.read_bytes()).hexdigest(),
    'duration_seconds': float(meta['format']['duration']),
    'dimensions': [v['width'], v['height']],
    'fps': v['avg_frame_rate'], 'frames': int(v['nb_frames']),
    'video_codec': v['codec_name'], 'pixel_format': v['pix_fmt'],
    'color_range': v.get('color_range'), 'color_space': v.get('color_space'),
    'audio_codec': a['codec_name'], 'audio_sample_rate': a['sample_rate'],
    'audio_channels': a['channels'], 'full_decode': 'passed',
    'audio_peak_dbfs': round(float(20 * np.log10(peak)), 2),
    'synthetic_sfx_regions': regions, 'music': False, 'voiceover': False,
    'source_audio_muted': True, 'typescript': 'passed',
    'visual_inspection': '12 Remotion stills and 18 encoded-video frames, including opening, cuts and final card',
    'renderer': 'Remotion 4.0.538, then FFmpeg Rec.709 delivery normalization',
}
(ROOT / 'out/verification.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
print(json.dumps(report, indent=2, ensure_ascii=False))
