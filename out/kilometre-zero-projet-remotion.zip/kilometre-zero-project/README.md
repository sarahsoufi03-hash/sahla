# Kilomètre Zéro — Reel SAHLA

Montage Remotion de la vidéo fournie, sans régénération des scènes.
Cible : runners et boutiques de running. Objectif : vues et abonnements à
**@sahladzai**, sans vente directe. Aucun service payant, aucune musique,
aucune voix off. Sept accents synthétiques originaux.

## Ouvrir et modifier

Depuis ce dossier, avec Node.js 22 ou 24 et npm :

```bash
npm ci
npm run studio
```

La composition **KilometreZero** dure 1 800 images : **30 s**, **60 fps**,
**1080 × 1920**. Ouvrir son aperçu dans Remotion Studio.
Chaque plan, surimpression et bruitage possède une séquence nommée dans
`src/KilometreZero.tsx`. Les médias restent dans `public/`.

```bash
npm run typecheck
npm run preview
npm run render
```

Le rendu final est `out/kilometre-zero-final.mp4`, H.264, yuv420p, AAC stéréo.
FFmpeg est également requis pour la normalisation finale Rec.709 et le
placement de l'index MP4 en tête de fichier. Le rendu Remotion intermédiaire
est conservé dans `out/kilometre-zero-remotion.mp4`.
Le navigateur Chromium installé est utilisé sur cette machine ; sur un autre
système, Remotion utilisera son navigateur géré. Un chemin peut être fourni via
`REMOTION_BROWSER_EXECUTABLE`. Nul besoin de modifier la configuration Codex.
Utiliser le checkout existant : chaque tâche cloud est déjà isolée, aucun nouveau
worktree n'est nécessaire.

## Structure du montage, étendue à 30 secondes

| Temps de sortie | Plan / traitement |
| --- | --- |
| 0–0,8 s | Chaussure éclatée, hook blanc/orange visible dès l'image 0 |
| 0,8–4,8 s | Assemblage resserré, invitation au scroll |
| 4,8–6,5 s | Révélation du site ; phrases originales conservées et raccourcies |
| 6,5–10,5 s | Page produit ordinateur, léger recadrage animé |
| 10,5–14 s | Ordinateur et téléphone, interfaces conservées |
| 14–19 s | Page éclatée en 3D, ralentie pour respirer |
| 19–23,2 s | Runners et Alger |
| 23,2–25,3 s | Retour sportif et assombrissement bref vers la carte |
| 25,3–30 s | Carte « Pour d’autres sites comme ça, suis @sahladzai » |

Les premières étapes reprennent les points de coupe demandés. La durée
supplémentaire est donnée aux vues du site et à Alger plutôt qu'à une longue
carte immobile. La consigne finale « vues + abonnés » remplace l'ancien CTA de
vente par DM. Mention discrète : « Projet fictif — démo SAHLA ».

## Source et son

`public/source.mp4` : fichier fourni, 29,983333 s, H.264, 1080 × 1920,
60 fps, audio AAC 48 kHz stéréo. La piste source est silencieuse (maximum
mesuré -91 dBFS) ; elle est coupée dans le montage.

`public/end-devices.png` est une extraction du même fichier à 19,5 secondes,
recadrée sur les appareils entiers. Aucune image du site n'a été générée.
Les recadrages de textes déjà présents dans la source, notamment le titre
« VERROUILLÉ. » en haut du plan d'assemblage, ne sont pas reconstruits.

`scripts/make-sfx.py` génère les sept bruitages : numpy + scipy, seed fixe,
48 kHz stéréo. Les WAV sont inclus, donc Python n'est pas nécessaire pour
modifier ou rendre la vidéo. Sons originaux sous CC0, sans bibliothèque tierce.
Les polices locales DejaVu sont incluses avec leur licence.

## Vérifications

- `npm run typecheck` pour la composition.
- `node scripts/render-checks.mjs` pour douze images de contrôle.
- Aperçu vidéo à demi-résolution, puis rendu final à pleine résolution.
- Contrôle ffprobe, décodage complet, niveaux et événements audio après rendu.
- `analysis/` et `out/` contiennent les éléments de contrôle locaux et les
  exports ; les sorties sont exclues de Git.

Le fichier `out/verification.json` consigne les résultats techniques du rendu
livré. Les interfaces natives du site sont des pixels de la source ; les
surimpressions et les coupes restent modifiables dans Remotion.
